create trigger like_AFTER_INSERT
  after INSERT
  on `like`
  for each row
  BEGIN
	UPDATE user SET like_count=like_count+1 WHERE id=NEW.target_user_id;
    UPDATE treasure SET like_count=like_count+1 WHERE id=NEW.treasure_id;
END;

