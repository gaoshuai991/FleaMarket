create trigger treasure_view_AFTER_INSERT
  after INSERT
  on treasure_view
  for each row
  BEGIN
    UPDATE treasure SET view_count=view_count+1 WHERE id=new.treasure_id;
  END;

