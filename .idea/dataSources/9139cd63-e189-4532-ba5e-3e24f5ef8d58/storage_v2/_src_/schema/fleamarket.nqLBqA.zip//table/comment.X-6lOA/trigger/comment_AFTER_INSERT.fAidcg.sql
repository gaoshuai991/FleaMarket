create trigger comment_AFTER_INSERT
  after INSERT
  on comment
  for each row
  BEGIN
	UPDATE treasure SET comment_count=comment_count+1 WHERE id=NEW.treasure_id;
END;

