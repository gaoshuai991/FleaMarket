create trigger treasure_star_AFTER_INSERT
  after INSERT
  on treasure_star
  for each row
  BEGIN
	UPDATE user SET star_count=star_count+1 WHERE id=new.user_id; 
END;

