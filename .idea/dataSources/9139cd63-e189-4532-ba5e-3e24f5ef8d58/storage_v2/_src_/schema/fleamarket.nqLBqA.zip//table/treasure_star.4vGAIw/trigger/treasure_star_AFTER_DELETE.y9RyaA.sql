create trigger treasure_star_AFTER_DELETE
  after DELETE
  on treasure_star
  for each row
  BEGIN
    UPDATE user SET star_count=star_count-1 WHERE id=old.user_id;
  END;

